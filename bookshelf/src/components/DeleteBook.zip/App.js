function App() {
    return (<div>
        <h1> Hello Universe!</h1>
        <p>The nebula is beautiful today.</p>
    </div>);
}


export default App;